# =============================================================================
# gene_mapping.R - probe / feature -> HGNC symbol, and probe -> gene collapse.
# Collapsing rule (an assumption of this repo; state it in Methods): when
# several probes map to one symbol keep the probe with the highest mean
# expression across samples. Probes with no symbol, or mapping to several
# symbols (";" / "///"), are dropped.
# =============================================================================
suppressPackageStartupMessages({ library(AnnotationDbi) })

.clean_map <- function(ids, syms) {
  m <- data.frame(id = ids, symbol = syms, stringsAsFactors = FALSE)
  m <- m[!is.na(m$symbol) & m$symbol != "" & !grepl("///|;", m$symbol), ]
  setNames(m$symbol, m$id)
}
.map_with_db <- function(probes, db) {
  s <- suppressMessages(AnnotationDbi::mapIds(db, keys = probes, column = "SYMBOL",
                                              keytype = "PROBEID", multiVals = "first"))
  .clean_map(names(s), unname(s))
}

map_gpl570   <- function(probes) { library(hgu133plus2.db); .map_with_db(probes, hgu133plus2.db) }
map_gpl6244  <- function(probes) { library(hugene10sttranscriptcluster.db); .map_with_db(probes, hugene10sttranscriptcluster.db) }
map_gpl10558 <- function(probes) {
  library(illuminaHumanv4.db)
  s <- suppressMessages(AnnotationDbi::mapIds(illuminaHumanv4.db, keys = probes, column = "SYMBOL",
                                              keytype = "PROBEID", multiVals = "first"))
  .clean_map(names(s), unname(s))
}
# Agilent GPL4133: use the symbol column shipped in the GEO feature data.
map_gpl4133_agilent <- function(eset) {
  fd <- Biobase::fData(eset)
  col <- grep("^gene[_ ]?symbol$|^symbol$", colnames(fd), ignore.case = TRUE, value = TRUE)[1]
  if (is.na(col)) stop("No gene-symbol column in GPL4133 fData; columns are: ", paste(colnames(fd), collapse = ", "))
  .clean_map(rownames(fd), as.character(fd[[col]]))
}
# RNA-seq feature ids: Ensembl (ENSG...) -> symbol, or already symbols.
map_rnaseq_features <- function(ids) {
  if (mean(grepl("^ENSG", ids)) > 0.5) {
    library(org.Hs.eg.db)
    base <- sub("\\..*$", "", ids)
    s <- suppressMessages(AnnotationDbi::mapIds(org.Hs.eg.db, keys = base, column = "SYMBOL",
                                                keytype = "ENSEMBL", multiVals = "first"))
    .clean_map(ids, unname(s[base]))
  } else .clean_map(ids, ids)
}

collapse_to_gene_symbol <- function(expr, id2symbol) {
  keep <- rownames(expr) %in% names(id2symbol)
  expr <- expr[keep, , drop = FALSE]
  sym  <- unname(id2symbol[rownames(expr)])
  ord  <- order(rowMeans(expr, na.rm = TRUE), decreasing = TRUE)
  expr <- expr[ord, , drop = FALSE]; sym <- sym[ord]
  expr <- expr[!duplicated(sym), , drop = FALSE]
  rownames(expr) <- sym[!duplicated(sym)]
  expr
}
