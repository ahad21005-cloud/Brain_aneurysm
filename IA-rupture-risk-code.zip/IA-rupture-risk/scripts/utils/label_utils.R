# =============================================================================
# label_utils.R - turn GEO sample metadata into analysis labels.
#
# !! VERIFY BEFORE TRUSTING !!  GEO metadata wording differs per series. Each
# function matches keywords in ALL text columns of pData for a sample. After
# running 02_inspect_metadata.R, compare the counts printed by check_labels()
# with the cohort table in the paper (Table 1). If a count is off, edit the
# keyword rule for that cohort here - nowhere else.
#
# Output labels:  "control" | "unruptured" | "ruptured"      (tissue cohorts)
#                 "aneurysm" (rupture status not given)       (GSE75436)
#                 "SAH" | "control"                           (blood, GSE36791)
# NA = cannot be resolved -> sample is dropped and logged (see 03 scripts).
# GSE6551 is intentionally NOT used (excluded in the paper).
# =============================================================================

pd_text <- function(pd) {
  cols <- colnames(pd)[vapply(pd, function(x) is.character(x) || is.factor(x), logical(1))]
  tolower(apply(pd[, cols, drop = FALSE], 1, function(r) paste(as.character(r), collapse = " | ")))
}

# generic rupture-status rule; "unrupt" must be tested BEFORE "rupt"
rupture_rule <- function(txt, control_pattern = "control|normal|healthy|artery|sta\\b|superficial temporal|meningeal") {
  out <- rep(NA_character_, length(txt))
  out[grepl(control_pattern, txt)]                        <- "control"
  out[grepl("ruptur", txt)]                               <- "ruptured"
  out[grepl("unruptur|non-ruptur|not ruptur|\\buia\\b", txt)] <- "unruptured"
  out
}

label_gse122897 <- function(pd) {
  txt <- pd_text(pd)
  out <- rupture_rule(txt, control_pattern = "control|normal|healthy|cortical")
  out[grepl("undetermined|unknown|n/a", txt) & !(out %in% c("control"))] <- NA  # 1 aneurysm has undetermined status
  out
}
label_gse13353 <- function(pd) { o <- rupture_rule(pd_text(pd), control_pattern = "^$"); o }
label_gse15629 <- function(pd) rupture_rule(pd_text(pd), control_pattern = "control|normal|middle meningeal|mma")
label_gse54083 <- function(pd) rupture_rule(pd_text(pd), control_pattern = "control|normal|superficial temporal|\\bsta\\b")
label_gse26969 <- function(pd) {
  txt <- pd_text(pd); o <- rep(NA_character_, length(txt))
  o[grepl("control|normal|superficial temporal|\\bsta\\b|sta ", txt)] <- "control"
  o[grepl("aneurysm|\\bia\\b|unruptur", txt) & !grepl("control|normal", txt)] <- "unruptured"
  o
}
label_gse75436 <- function(pd) {            # aneurysm vs matched STA; rupture status not used
  txt <- pd_text(pd); o <- rep(NA_character_, length(txt))
  o[grepl("aneurysm|\\bia\\b|\\bmca\\b|dome|wall", txt)] <- "aneurysm"
  o[grepl("control|normal|superficial temporal|\\bsta\\b", txt)] <- "control"
  o
}
label_gse36791 <- function(pd) {            # blood: SAH patients vs healthy/neurology controls
  txt <- pd_text(pd); o <- rep(NA_character_, length(txt))
  o[grepl("control|healthy|headache|normal", txt)] <- "control"
  o[grepl("sah|subarachnoid|aneurysm|patient", txt) & !grepl("control|healthy|headache", txt)] <- "SAH"
  o
}

# Pair IDs for GSE75436 (15 aneurysm + 15 matched STA). EDIT the regex after
# inspecting pdata_GSE75436.csv. The function STOPS unless every pair id occurs
# exactly twice (one aneurysm + one control) - this is the "pairing verified" check.
get_pair_id_gse75436 <- function(pd, status) {
  txt <- pd_text(pd)
  id <- sub(".*?(patient|subject|pt|case)[ _#:-]*([0-9]+).*", "\\2", txt, perl = TRUE)
  id[!grepl("(patient|subject|pt|case)[ _#:-]*[0-9]+", txt)] <- NA
  if (anyNA(id)) stop("Could not parse a pair id for every GSE75436 sample - edit get_pair_id_gse75436().")
  tab <- table(id, status)
  stopifnot(all(tab == 1))
  id
}

check_labels <- function(status, cohort) {
  cat(sprintf("[%s] label counts: ", cohort)); print(table(status, useNA = "ifany"))
  if (all(is.na(status))) stop("No labels resolved for ", cohort, " - fix label rule.")
  invisible(status)
}
