# meta_utils.R - effect sizes and pooling used by 07_signature_score_meta.R
# Hedges' g (small-sample corrected SMD), unpaired and paired; DerSimonian-Laird
# random effects with t-distribution CI (k-1 df); fixed-effect pooling; I^2.

hedges_g <- function(x1, x2) {
  n1 <- length(x1); n2 <- length(x2)
  sp <- sqrt(((n1 - 1) * var(x1) + (n2 - 1) * var(x2)) / (n1 + n2 - 2))
  d  <- (mean(x1) - mean(x2)) / sp
  J  <- 1 - 3 / (4 * (n1 + n2) - 9)
  g  <- J * d
  se <- sqrt((n1 + n2) / (n1 * n2) + g^2 / (2 * (n1 + n2)))
  c(g = g, se = se, n1 = n1, n2 = n2)
}

# Paired design: standardise the mean of the pair differences by the SD of the
# differences (d_z), small-sample corrected with df = n-1.
hedges_g_paired <- function(x1, x2) {
  stopifnot(length(x1) == length(x2))
  dif <- x1 - x2; n <- length(dif)
  dz <- mean(dif) / sd(dif)
  J  <- 1 - 3 / (4 * (n - 1) - 1)
  g  <- J * dz
  se <- sqrt(1 / n + g^2 / (2 * n))
  c(g = g, se = se, n1 = n, n2 = n)
}

pool_random <- function(g, se) {
  k <- length(g); w <- 1 / se^2
  g_fe <- sum(w * g) / sum(w)
  Q <- sum(w * (g - g_fe)^2)
  C <- sum(w) - sum(w^2) / sum(w)
  tau2 <- max(0, (Q - (k - 1)) / C)
  ws <- 1 / (se^2 + tau2)
  est <- sum(ws * g) / sum(ws); se_re <- sqrt(1 / sum(ws))
  tcrit <- qt(0.975, df = k - 1)
  I2 <- if (Q > 0) max(0, (Q - (k - 1)) / Q) else 0
  p <- 2 * pt(-abs(est / se_re), df = k - 1)
  c(g = est, se = se_re, lo = est - tcrit * se_re, hi = est + tcrit * se_re,
    p = p, I2 = I2, tau2 = tau2, Q = Q, k = k)
}

pool_fixed <- function(g, se) {
  w <- 1 / se^2; est <- sum(w * g) / sum(w); s <- sqrt(1 / sum(w))
  c(g = est, se = s, lo = est - 1.96 * s, hi = est + 1.96 * s,
    p = 2 * pnorm(-abs(est / s)), k = length(g))
}

ci95 <- function(g, se) c(lo = g - 1.96 * se, hi = g + 1.96 * se)
