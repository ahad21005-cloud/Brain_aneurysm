# =============================================================================
# classifier_utils.R - the ONE definition of the classifier pipeline, shared by
# 05 (observed), 05c (stability) and 06 (frozen model). 05b_permutation_test.R
# contains an identical copy so it can run standalone.
#
# Pipeline inside every training fold:
#   label-blind candidate pool (top-5000 variance genes, computed once, no labels)
#   -> LASSO logistic (lambda.1se -> lambda.min -> smallest lambda with >=2 genes
#      -> top-2 univariate) -> random forest (500 trees) -> AUC on held-out fold
#      with explicit direction ("<": ruptured scores higher).
# =============================================================================
suppressPackageStartupMessages({ library(glmnet); library(randomForest); library(pROC) })
POOL_N <- 5000; N_TREES <- 500; K_FOLDS <- 5
CLASS_LEVELS <- c("not_ruptured", "ruptured")

make_outcome <- function(status) factor(ifelse(status == "ruptured", "ruptured", "not_ruptured"), levels = CLASS_LEVELS)

variance_pool <- function(expr, n = POOL_N) {          # expr: genes x samples; uses NO labels
  v <- apply(expr, 1, var); names(sort(v, decreasing = TRUE))[seq_len(min(n, length(v)))]
}
.nonzero <- function(cv, s) { b <- coef(cv, s = s); setdiff(rownames(b)[b[, 1] != 0], "(Intercept)") }

select_panel <- function(Xtr, ytr) {
  cv <- cv.glmnet(Xtr, ytr, family = "binomial", alpha = 1, nfolds = 5)
  g <- .nonzero(cv, "lambda.1se"); rule <- "lambda.1se"
  if (length(g) < 2) { g <- .nonzero(cv, "lambda.min"); rule <- "lambda.min" }
  if (length(g) < 2) {
    k <- which(cv$glmnet.fit$df >= 2)
    if (length(k)) { g <- .nonzero(cv, cv$glmnet.fit$lambda[min(k)]); rule <- "path_ge2" }
  }
  if (length(g) < 2) {
    tt <- apply(Xtr, 2, function(x) tryCatch(abs(unname(t.test(x ~ ytr)$statistic)), error = function(e) 0))
    g <- names(sort(tt, decreasing = TRUE))[1:2]; rule <- "top2_univariate"
  }
  list(genes = g, rule = rule)
}
make_folds <- function(y, k = K_FOLDS) {
  f <- integer(length(y))
  for (cl in levels(y)) { i <- which(y == cl); f[i] <- sample(rep_len(seq_len(k), length(i))) }
  f
}
fold_auc <- function(X, y, tr, te) {
  sel <- select_panel(X[tr, , drop = FALSE], y[tr])
  rf  <- randomForest(x = X[tr, sel$genes, drop = FALSE], y = y[tr], ntree = N_TREES)
  p   <- predict(rf, X[te, sel$genes, drop = FALSE], type = "prob")[, "ruptured"]
  list(auc = as.numeric(auc(roc(y[te], p, levels = CLASS_LEVELS, direction = "<", quiet = TRUE))), rule = sel$rule)
}
cv_stat <- function(X, y, n_rep) {
  aucs <- c(); rules <- c()
  for (r in seq_len(n_rep)) {
    f <- make_folds(y)
    for (k in seq_len(K_FOLDS)) {
      o <- fold_auc(X, y, which(f != k), which(f == k)); aucs <- c(aucs, o$auc); rules <- c(rules, o$rule)
    }
  }
  list(auc = mean(aucs), fold_aucs = aucs, rules = rules)
}
